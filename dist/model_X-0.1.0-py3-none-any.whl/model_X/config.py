bilstm_lstm_gru = {
    "h_lstm":128,
    "h_gru":256,
    "is_embedding_trainable":True,
    "embedding_matrix":None,
    "embedding_size":1000
}

bilstm_lstm_gru_selfattention = {
    "h_lstm":128,
    "h_gru":256,
    "is_embedding_trainable":True,
    "embedding_matrix":None,
    "embedding_size":1000
}

bilstm_lstm_gru_multiheadattention = {
    "h_lstm":128,
    "h_gru":256,
    "is_embedding_trainable":True,
    "embedding_matrix":None,
    "embedding_size":1000,
    "head_num":3
}

